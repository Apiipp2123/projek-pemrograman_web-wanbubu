<?php
// =========================================================================
// SISTEM DETEKSI ERROR OTOMATIS (AGAR TIDAK BLANK)
// =========================================================================
if (isset($_GET['action'])) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1); // Izinkan cetak error agar ditangkap oleh JavaScript
    ob_start(); // Amankan buffer luar
} else {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

// 1. KONEKSI DATABASE STANDALONE
$host = 'localhost';
$dbname = 'wanbubu_db'; // <--- PASTIKAN NAMA DATABASE KAMU BENAR
$db_user = 'root';   // <--- Username Laragon
$db_pass = '';       // <--- Password Laragon (kosongkan jika default)

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $db_user, $db_pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    if (isset($_GET['action'])) {
        echo "DATABASE ERROR: " . $e->getMessage();
        exit;
    }
    die("Koneksi Database Gagal: " . $e->getMessage());
}

// =========================================================================
// ENDPOINT AJAX 1: PROSES KIRIM KODE OTP
// =========================================================================
if (isset($_GET['action']) && $_GET['action'] === 'send_otp') {
    if (session_status() === PHP_SESSION_NONE) { session_start(); }
    
    // Proteksi jika folder PHPMailer salah letak
    if (!file_exists(__DIR__ . '/PHPMailer/src/PHPMailer.php')) {
        echo "PHPMailer ERROR: Folder 'PHPMailer' tidak ditemukan di sebelah file register.php! Periksa kembali struktur folder kamu.";
        exit;
    }

    require __DIR__ . '/PHPMailer/src/Exception.php';
    require __DIR__ . '/PHPMailer/src/PHPMailer.php';
    require __DIR__ . '/PHPMailer/src/SMTP.php';

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    $email = trim($_POST['email'] ?? '');
    $username = trim($_POST['username'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Format email tidak valid!']);
        exit;
    }

    // Cek username/email ganda
    $stmt = $db->prepare("SELECT id FROM users WHERE username = :u OR email = :e");
    $stmt->execute(['u' => $username, 'e' => $email]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Username atau Email sudah terdaftar di database!']);
        exit;
    }

    $otpCode = rand(100000, 999999);
    $_SESSION['reg_otp'] = $otpCode;
    $_SESSION['reg_otp_expires'] = time() + 300;

    $mail = new PHPMailer(true);
    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'alghozali2123@gmail.com';       // GANTI DENGAN EMAIL GMAILMU
        $mail->Password   = 'bnjq kvde leqi qrgm';           // GANTI DENGAN 16 DIGIT SANDI APLIKASI
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        
        $mail->setFrom('email_kamu@gmail.com', 'Wanbubu System');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Kode OTP Pendaftaran Wanbubu';
        $mail->Body    = "<h3>Kode OTP Anda adalah: <b>$otpCode</b></h3><p>Berlaku selama 5 menit.</p>";

        $mail->send();
        echo json_encode(['success' => true, 'message' => 'Kode OTP berhasil dikirim ke Gmail Anda!']);
    } catch (Exception $e) {
        echo "SMTP EMAIL ERROR: " . $mail->ErrorInfo;
    }
    exit;
}

// =========================================================================
// ENDPOINT AJAX 2: PROSES PENDAFTARAN AKHIR
// =========================================================================
if (isset($_GET['action']) && $_GET['action'] === 'register_user') {
    if (session_status() === PHP_SESSION_NONE) { session_start(); }
    
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $nama = trim($_POST['nama_lengkap'] ?? '');
    $inputOtp = trim($_POST['otp_code'] ?? '');

    if (empty($username) || empty($email) || empty($password) || empty($nama) || empty($inputOtp)) {
        echo json_encode(['success' => false, 'message' => 'Semua field wajib diisi termasuk kode OTP!']); exit;
    }
    if ($password !== $confirm) {
        echo json_encode(['success' => false, 'message' => 'Konfirmasi password tidak cocok!']); exit;
    }
    if ($inputOtp != ($_SESSION['reg_otp'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Kode OTP yang dimasukkan salah atau tidak valid!']); exit;
    }
    if (time() > ($_SESSION['reg_otp_expires'] ?? 0)) {
        echo json_encode(['success' => false, 'message' => 'Kode OTP sudah kedaluwarsa!']); exit;
    }

    try {
        $stmt = $db->prepare("INSERT INTO users (username, email, password, nama_lengkap) VALUES (:u, :e, :p, :n)");
        $stmt->execute([
            'u' => $username,
            'e' => $email,
            'p' => password_hash($password, PASSWORD_DEFAULT),
            'n' => $nama
        ]);
        unset($_SESSION['reg_otp'], $_SESSION['reg_otp_expires']);
        echo json_encode(['success' => true, 'message' => 'Akun berhasil dibuat! Silakan menuju halaman login.']);
    } catch (PDOException $e) {
        echo "SQL INSERT ERROR: " . $e->getMessage();
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - Wanbubu</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #4CAF50; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: linear-gradient(135deg, #e8f5e9, #c8e6c9); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .register-card { background: white; border-radius: 20px; padding: 40px; width: 420px; box-shadow: 0 20px 60px rgba(0,0,0,0.1); }
        .logo { width: 70px; height: 70px; background: linear-gradient(135deg, #4CAF50, #66BB6A); border-radius: 15px; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 30px; color: white; }
        .register-card h2 { text-align: center; color: #333; margin-bottom: 5px; }
        .register-card .subtitle { text-align: center; color: #666; margin-bottom: 25px; font-size: 14px; }
        .alert { padding: 12px 15px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; display: none; align-items: center; gap: 10px; line-height: 1.4; word-break: break-all; }
        .alert-error { background: #fff5f5; color: #c62828; border: 1px solid #ffcdd2; }
        .alert-success { background: #e8f5e9; color: #2e7d32; border: 1px solid #c8e6c9; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px; color: #333; }
        .form-group input { width: 100%; padding: 12px 15px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 14px; transition: all 0.3s; }
        .form-group input:focus { outline: none; border-color: #4CAF50; }
        .inline-input-group { display: flex; gap: 8px; }
        .btn-send-otp { padding: 0 15px; background: #2196F3; color: white; border: none; border-radius: 10px; font-weight: 600; font-size: 13px; cursor: pointer; white-space: nowrap; }
        .btn-send-otp:disabled { background: #bbb; }
        .btn-register { width: 100%; padding: 14px; background: #4CAF50; color: white; border: none; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer; margin-top: 10px; }
        .links { text-align: center; margin-top: 20px; }
        .links a { color: #4CAF50; text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
    <div class="register-card">
        <div class="logo">🥗</div>
        <h2>Daftar Akun</h2>
        <p class="subtitle">Bergabung dengan Wanbubu</p>
        
        <div id="alert_box" class="alert"></div>
        
        <form id="register_form">
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" name="nama_lengkap" id="nama_lengkap" required placeholder="Masukkan nama lengkap">
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" id="username" required placeholder="Masukkan username">
            </div>
            <div class="form-group">
                <label>Email</label>
                <div class="inline-input-group">
                    <input type="email" name="email" id="email" required placeholder="Masukkan email">
                    <button type="button" id="btn_otp" class="btn-send-otp">Kirim OTP</button>
                </div>
            </div>
            <div class="form-group" id="otp_wrapper" style="display: none; background: #f4fbf7; padding: 12px; border: 1px dashed #4CAF50; border-radius: 10px;">
                <label style="color: #2e7d32;">Masukkan 6 Digit OTP Gmail</label>
                <input type="text" name="otp_code" id="otp_code" maxlength="6" placeholder="••••••" style="text-align: center; letter-spacing: 6px; font-weight: bold; font-size: 16px; border-color: #4CAF50;">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" id="password" required placeholder="Minimal 6 karakter">
            </div>
            <div class="form-group">
                <label>Konfirmasi Password</label>
                <input type="password" name="confirm_password" id="confirm_password" required placeholder="Ulangi password">
            </div>
            <button type="submit" id="btn_submit" class="btn-register">Daftar Akun</button>
        </form>
        
        <div class="links">
            <p style="color:#666;">Sudah punya akun? <a href="login.php">Login di sini</a></p>
            <p><a href="index.php">← Kembali ke Beranda</a></p>
        </div>
    </div>

    <script>
        const baseUrl = window.location.origin + window.location.pathname;
        const alertBox = document.getElementById('alert_box');
        const btnOtp = document.getElementById('btn_otp');
        const otpWrapper = document.getElementById('otp_wrapper');
        const registerForm = document.getElementById('register_form');
        const btnSubmit = document.getElementById('btn_submit');

        function showAlert(type, message) {
            alertBox.style.display = 'flex';
            alertBox.className = `alert alert-${type}`;
            alertBox.innerHTML = message;
        }

        btnOtp.addEventListener('click', function() {
            const email = document.getElementById('email').value;
            const username = document.getElementById('username').value;

            if (!username || !email) {
                showAlert('error', 'Isi Username dan Email dahulu baru klik tombol OTP!');
                return;
            }

            btnOtp.disabled = true;
            btnOtp.innerText = 'Mengirim...';
            showAlert('success', 'Sedang memproses pengiriman OTP ke Gmail...');

            const formData = new FormData();
            formData.append('email', email);
            formData.append('username', username);

            fetch(baseUrl + '?action=send_otp', { method: 'POST', body: formData })
            .then(async res => {
                const text = await res.text();
                try { return JSON.parse(text); } catch(e) { return { success: false, message: text }; }
            })
            .then(data => {
                if (data.success) {
                    showAlert('success', data.message);
                    otpWrapper.style.display = 'block';
                    btnOtp.innerText = 'Kirim Ulang';
                } else {
                    showAlert('error', data.message);
                    btnOtp.innerText = 'Kirim OTP';
                }
                btnOtp.disabled = false;
            })
            .catch(err => {
                showAlert('error', 'Gagal memproses request.');
                btnOtp.disabled = false;
            });
        });

        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (otpWrapper.style.display === 'none') {
                showAlert('error', 'Wajib klik "Kirim OTP" terlebih dahulu!');
                return;
            }

            btnSubmit.disabled = true;
            btnSubmit.innerText = 'Mendaftarkan...';

            const formData = new FormData(registerForm);
            fetch(baseUrl + '?action=register_user', { method: 'POST', body: formData })
            .then(async res => {
                const text = await res.text();
                try { return JSON.parse(text); } catch(e) { return { success: false, message: text }; }
            })
            .then(data => {
                if (data.success) {
                    showAlert('success', data.message + '<br><a href="login.php" style="color:#2e7d32;font-weight:bold;">Klik di sini untuk Login</a>');
                    registerForm.reset();
                    otpWrapper.style.display = 'none';
                    btnSubmit.style.display = 'none';
                } else {
                    showAlert('error', data.message);
                    btnSubmit.disabled = false;
                    btnSubmit.innerText = 'Daftar Akun';
                }
            });
        });
    </script>
</body>
</html>

