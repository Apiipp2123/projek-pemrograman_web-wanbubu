<?php
// 1. SETUP & INTEGRASI BACKEND
require_once __DIR__ . '/app/helpers/Session.php';
require_once __DIR__ . '/app/models/User.php';
require __DIR__ . '/PHPMailer/src/Exception.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';

// Load PHPMailer (Gunakan vendor/autoload.php jika install lewat Composer)
// Jika kamu download PHPMailer manual, sesuaikan path require_once ke file PHPMailer kamu.
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
}

Session::start();

// Jika sudah resmi login, langsung redirect sesuai role
if(Session::isLoggedIn()) {
    if(Session::isAdmin()) {
        header('Location: /wanbubu/admin.php');
    } else {
        header('Location: /wanbubu/');
    }
    exit;
}

$error = '';
// Status untuk mengontrol form mana yang muncul ('login' atau 'otp')
$status = (Session::get('otp_step') === true) ? 'otp' : 'login';

// Fungsi Backend untuk Mengirim Email via SMTP Gmail
function kirimEmailOTP($emailTujuan, $kodeOtp) {
    $mail = new PHPMailer(true);
    try {
        // Konfigurasi Server SMTP Gmail
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'alghozali2123@gmail.com'; // Email pengirim
    $mail->Password   = 'awzp ijjk ezej tacv';       // 16 digit Sandi Aplikasi tadi
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;
    $mail->setFrom('alghozali2123@gmail.com', 'wanbubu');

        // Pengirim & Penerima
        $mail->setFrom('email_kamu@gmail.com', 'Wanbubu System');
        $mail->addAddress($emailTujuan);

        // Konten Email
        $mail->isHTML(true);
        $mail->Subject = 'Kode OTP Login Wanbubu';
        $mail->Body    = "
            <div style='font-family: Arial, sans-serif; padding: 20px; border: 1px solid #e0e0e0; border-radius: 10px; max-width: 500px;'>
                <h2 style='color: #4CAF50;'>Verifikasi Akun Wanbubu</h2>
                <p>Halo, kami mendeteksi adanya aktivitas login ke akun Anda. Gunakan kode OTP di bawah ini untuk melanjutkan:</p>
                <div style='background: #f4f4f4; padding: 15px; text-align: center; font-size: 24px; font-weight: bold; letter-spacing: 5px; color: #333; border-radius: 5px; margin: 20px 0;'>
                    $kodeOtp
                </div>
                <p style='color: #777; font-size: 12px;'>Kode ini hanya berlaku selama 5 menit. Jangan bagikan kode ini kepada siapapun demi keamanan akun Anda.</p>
            </div>
        ";

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

// MANAGEMENT REQUEST POST
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // -------------------------------------------------------------
    // PROSES LANGKAH 1: LOGIN USERNAME & PASSWORD
    // -------------------------------------------------------------
    if (isset($_POST['action']) && $_POST['action'] === 'proses_login') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if(empty($username) || empty($password)) {
            $error = 'Username dan password harus diisi!';
        } else {
            $userModel = new User();
            $user = $userModel->login($username, $password);
            
            // Pastikan method login() mengembalikan data user termasuk kolom 'email'
            if($user && isset($user['email'])) {
                // Generate OTP 6 digit acak
                $otpCode = rand(100000, 999999);
                
                // Simpan data sementara ke dalam session
                Session::set('temp_user', $user);
                Session::set('otp_code', $otpCode);
                Session::set('otp_expires', time() + 300); // Kadaluwarsa dalam 5 menit (300 detik)
                Session::set('otp_step', true);
                
                // Kirim OTP ke Gmail user
                if (kirimEmailOTP($user['email'], $otpCode)) {
                    $status = 'otp'; // Pindah ke form OTP
                } else {
                    $error = 'Gagal mengirimkan kode OTP ke email Anda. Silakan coba lagi nanti.';
                    Session::destroy();
                    $status = 'login';
                }
            } else {
                $error = 'Username atau password salah!';
            }
        }
    }
    
    // -------------------------------------------------------------
    // PROSES LANGKAH 2: VERIFIKASI KODE OTP GMAIL
    // -------------------------------------------------------------
    if (isset($_POST['action']) && $_POST['action'] === 'proses_otp') {
        $inputOtp = trim($_POST['otp_code'] ?? '');
        
        // Cek apakah session OTP masih valid atau sudah kedaluwarsa
        if (time() > Session::get('otp_expires')) {
            $error = 'Kode OTP sudah kedaluwarsa! Silakan login ulang.';
            Session::destroy();
            $status = 'login';
        } 
        // Cocokkan OTP inputan user dengan yang disimpan di session
        elseif ($inputOtp == Session::get('otp_code')) {
            // Ambil data user yang disimpan sementara
            $user = Session::get('temp_user');
            
            // Daftarkan session login resmi
            Session::set('user_id', $user['id']);
            Session::set('username', $user['username']);
            Session::set('nama_lengkap', $user['nama_lengkap']);
            Session::set('role', $user['role']);
            
            // Bersihkan data temporary OTP
            Session::unset('temp_user');
            Session::unset('otp_code');
            Session::unset('otp_expires');
            Session::unset('otp_step');
            
            // Redirect sesuai role
            if($user['role'] === 'admin') {
                header('Location: /wanbubu/admin.php');
            } else {
                header('Location: /wanbubu/');
            }
            exit;
        } else {
            $error = 'Kode OTP yang Anda masukkan salah!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Wanbubu</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #4CAF50; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
        }
        
        .login-card {
            background: white; border-radius: 20px; padding: 40px;
            width: 400px; box-shadow: 0 20px 60px rgba(0,0,0,0.1);
        }
        
        .logo {
            width: 70px; height: 70px;
            background: linear-gradient(135deg, #4CAF50, #66BB6A);
            border-radius: 15px; display: flex; align-items: center; justify-content: center;
            margin: 0 auto 20px; font-size: 30px; color: white;
        }
        
        .login-card h2 { text-align: center; color: #333; margin-bottom: 5px; }
        .login-card .subtitle { text-align: center; color: #666; margin-bottom: 25px; font-size: 14px; }
        
        .error {
            background: #fff5f5; color: #c62828; padding: 12px 15px;
            border-radius: 10px; margin-bottom: 20px; font-size: 14px;
            display: flex; align-items: center; gap: 10px; border: 1px solid #ffcdd2;
        }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px; color: #333; }
        .input-icon { position: relative; }
        .input-icon i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #999; }
        .input-icon input {
            width: 100%; padding: 14px 15px 14px 45px;
            border: 2px solid #e0e0e0; border-radius: 12px;
            font-size: 15px; transition: all 0.3s;
        }
        .input-icon input:focus { outline: none; border-color: #4CAF50; }
        
        .btn-login {
            width: 100%; padding: 14px; background: #4CAF50; color: white;
            border: none; border-radius: 12px; font-size: 16px; font-weight: 600;
            cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;
            transition: background 0.3s;
        }
        .btn-login:hover { background: #388E3C; }
        
        .links { text-align: center; margin-top: 20px; }
        .links a { color: #4CAF50; text-decoration: none; font-weight: 600; }
        .links a:hover { text-decoration: underline; }
        .links p { color: #666; margin-top: 10px; font-size: 14px; }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="logo">🥗</div>
        
        <?php if($error): ?>
        <div class="error"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if($status === 'login'): ?>
        <h2>Login</h2>
        <p class="subtitle">Masuk ke akun Wanbubu Anda</p>
        
        <form method="POST">
            <input type="hidden" name="action" value="proses_login">
            <div class="form-group">
                <label>Username atau Email</label>
                <div class="input-icon">
                    <i class="fas fa-user"></i>
                    <input type="text" name="username" required placeholder="Masukkan username atau email">
                </div>
            </div>
            <div class="form-group">
                <label>Password</label>
                <div class="input-icon">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" required placeholder="Masukkan password">
                </div>
            </div>
            <button type="submit" class="btn-login"><i class="fas fa-sign-in-alt"></i> Masuk</button>
        </form>
        
        <?php else: ?>
        <h2>Verifikasi OTP</h2>
        <p class="subtitle">Kode OTP telah dikirim ke Gmail Anda. Berlaku selama 5 menit.</p>
        
        <form method="POST">
            <input type="hidden" name="action" value="proses_otp">
            <div class="form-group">
                <label>Masukkan 6 Digit Kode OTP</label>
                <div class="input-icon">
                    <i class="fas fa-key"></i>
                    <input type="text" name="otp_code" maxlength="6" required placeholder="••••••" 
                           style="text-align: center; letter-spacing: 8px; font-size: 20px; font-weight: bold;">
                </div>
            </div>
            <button type="submit" class="btn-login"><i class="fas fa-check-circle"></i> Verifikasi</button>
        </form>
        <?php endif; ?>
        
        <div class="links">
            <p>Belum punya akun? <a href="/wanbubu/register.php">Daftar di sini</a></p>
            <p><a href="/wanbubu/">← Kembali ke Beranda</a></p>
        </div>
    </div>
</body>
</html>